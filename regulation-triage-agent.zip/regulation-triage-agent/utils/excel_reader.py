import pandas as pd
import os

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "system_db.xlsx")

def load_system_db() -> dict:
    """
    Load all data from Excel system DB
    Returns dict with org profile, scope dimensions, tracked regulations
    """
    try:
        # Read all three sheets
        org_df = pd.read_excel(DB_PATH, sheet_name="organization_profile")
        scope_df = pd.read_excel(DB_PATH, sheet_name="scope_dimensions")
        regs_df = pd.read_excel(DB_PATH, sheet_name="tracked_regulations")

        # Parse organization profile
        org_profile = {}
        for _, row in org_df.iterrows():
            org_profile[row['field']] = row['value']

        # Parse scope dimensions
        scope_dimensions = []
        for _, row in scope_df.iterrows():
            scope_dimensions.append(f"{row['dimension_type']}: {row['value']}")

        # Parse tracked regulations
        tracked_regulations = []
        for _, row in regs_df.iterrows():
            if row.get('status', 'active') == 'active':
                tracked_regulations.append({
                    "id": row['id'],
                    "title": row['title'],
                    "identifier": row['identifier']
                })

        print(f" System DB loaded successfully")
        print(f"   Org Profile    : {org_profile.get('org_name', 'N/A')}")
        print(f"   Scope Dimensions: {len(scope_dimensions)} items")
        print(f"   Tracked Regs   : {len(tracked_regulations)} regulations")

        return {
            "organization_profile": org_profile.get('org_description', ''),
            "scope_dimensions": scope_dimensions,
            "tracked_regulations": tracked_regulations
        }

    except Exception as e:
        print(f"❌ Error loading system DB: {e}")
        raise