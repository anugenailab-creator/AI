from jsonschema import validate, ValidationError

# FROZEN OUTPUT SCHEMA - DO NOT CHANGE
TRIAGE_OUTPUT_SCHEMA = {
    "type": "object",
    "required": [
        "doc_id", "in_scope", "scope_reasoning",
        "relation_to_existing", "related_regulation_id",
        "confidence", "urgency_flag", "routing_decision"
    ],
    "properties": {
        "doc_id": {"type": "string"},
        "in_scope": {"type": "boolean"},
        "scope_reasoning": {"type": "string"},
        "relation_to_existing": {
            "type": "string",
            "enum": ["new", "amendment", "duplicate", "unrelated"]
        },
        "related_regulation_id": {"type": ["string", "null"]},
        "confidence": {
            "type": "number",
            "minimum": 0.0,
            "maximum": 1.0
        },
        "urgency_flag": {
            "type": "string",
            "enum": ["routine", "elevated", "urgent"]
        },
        "routing_decision": {
            "type": "string",
            "enum": [
                "queue_for_decomposition",
                "discard",
                "needs_human_triage"
            ]
        }
    },
    "additionalProperties": False
}

def validate_triage_output(data: dict) -> bool:
    """
    Validate triage output against frozen schema
    Never eyeball - always validate programmatically
    """
    try:
        validate(instance=data, schema=TRIAGE_OUTPUT_SCHEMA)
        print(f"✅ Schema validation passed")
        return True
    except ValidationError as e:
        print(f"❌ Schema validation FAILED: {e.message}")
        raise