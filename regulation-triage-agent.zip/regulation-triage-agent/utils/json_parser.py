import json
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def safe_parse_json(raw_response: str, agent_name: str, prompt_version: str) -> dict:
    """
    Safely parse JSON from LLM response
    - Strips markdown fences
    - Retries logic handled by caller
    - Never silently returns default
    - Logs model and prompt version (FR-53)
    """
    logger.info(f"Parsing response | Agent: {agent_name} | Prompt: {prompt_version}")

    # Strip markdown fences defensively
    cleaned = raw_response.strip()

    if "```json" in cleaned:
        cleaned = cleaned.split("```json")[1].split("```")[0]
    elif "```" in cleaned:
        cleaned = cleaned.split("```")[1].split("```")[0]

    cleaned = cleaned.strip()

    try:
        result = json.loads(cleaned)
        logger.info(f"✅ JSON parsed successfully | Agent: {agent_name}")
        return result
    except json.JSONDecodeError as e:
        logger.error(f"❌ JSON parse failed | Agent: {agent_name} | Error: {e}")
        raise ValueError(
            f"JSON parse failed for {agent_name}.\n"
            f"Raw response:\n{raw_response}"
        )