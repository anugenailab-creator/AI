import os
import sys
import json

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from agents.triage_agent import TriageAgent
from tests.test_documents import TEST_DOCUMENTS

def run_single_test(agent: TriageAgent, test_name: str, document: dict):
    """Run single test and display result"""
    print(f"\n{'#'*60}")
    print(f"# TEST: {test_name.upper()}")
    print(f"{'#'*60}")

    result = agent.run(document)
    agent.display_result(result)
    return result

def run_all_tests(agent: TriageAgent):
    """Run all 4 test cases"""
    results = {}

    for test_name, document in TEST_DOCUMENTS.items():
        result = run_single_test(agent, test_name, document)
        results[test_name] = result

    # Summary
    print(f"\n{'='*60}")
    print(f"📊 TEST SUMMARY")
    print(f"{'='*60}")
    print(f"{'Test':<30} {'Routing':<30} {'Confidence'}")
    print(f"{'-'*60}")
    for test_name, result in results.items():
        print(
            f"{test_name:<30} "
            f"{result.get('routing_decision', 'N/A'):<30} "
            f"{result.get('confidence', 0):.2f}"
        )
    print(f"{'='*60}")

    return results

def main():
    print("🚀 REGULATION TRIAGE AGENT - STARTING")
    print("="*60)

    # Initialize agent
    agent = TriageAgent()

    # Run all 4 tests
    run_all_tests(agent)

    print("\n✅ All tests completed!")

if __name__ == "__main__":
    main()