# ============================================================
# 4 TEST DOCUMENTS
# Test 1: Irrelevant → discard
# Test 2: Amendment  → queue_for_decomposition
# Test 3: Ambiguous  → needs_human_triage
# Test 4: New Reg    → queue_for_decomposition
# ============================================================

TEST_DOCUMENTS = {

    "test_1_irrelevant": {
        "doc_id": "TEST-001",
        "source": "FDA Portal",
        "title": "FDA Food Safety Modernization Act - Restaurant Hygiene Standards 2024",
        "doc_type": "Final Rule",
        "published_date": "2024-01-15",
        "source_url": "https://fda.gov/food-safety-2024",
        "raw_text": """
            FOOD SAFETY MODERNIZATION ACT - RESTAURANT HYGIENE STANDARDS
            
            This regulation establishes hygiene standards for food service 
            establishments including restaurants, cafeterias, and food trucks.
            
            Section 1: All food handlers must obtain food safety certification.
            Section 2: Kitchen surfaces must be sanitized every 4 hours.
            Section 3: Food storage temperatures must be maintained below 40°F.
            Section 4: Health inspections required quarterly.
            
            Effective Date: March 1, 2024
            Applies to: All food service establishments with more than 10 employees.
        """
    },

    "test_2_amendment": {
        "doc_id": "TEST-002",
        "source": "EPA Federal Register",
        "title": "EPA NOx Emission Standards Amendment - Heavy Duty Engines 2026",
        "doc_type": "Notice of Proposed Rulemaking",
        "published_date": "2026-07-01",
        "source_url": "https://epa.gov/nox-amendment-2026",
        "raw_text": """
            ENVIRONMENTAL PROTECTION AGENCY
            40 CFR Part 1036
            
            NOTICE OF PROPOSED RULEMAKING
            Heavy-Duty Engine NOx Emission Standards Amendment
            
            This rulemaking proposes to amend the existing 2023 EPA Heavy-Duty 
            Engine NOx Standards (40 CFR Part 1036) for heavy-duty diesel engines.
            
            Proposed Changes:
            Section 1: NOx emission limit revised from 0.035 g/hp-hr to 0.020 g/hp-hr
                        for model year 2030 and beyond engine families.
            
            Section 2: Useful life provisions extended:
                        - Previously: 435,000 miles or 22,000 hours
                        - Proposed: 450,000 miles or 24,000 hours
            
            Section 3: Warranty period extended from 5 years to 7 years
                        for emission-related components.
            
            Comment Deadline: September 15, 2026
            Effective Date: January 1, 2030 for MY2030 engines
            
            This amendment directly modifies EPA-2023-HDE-001 regulations
            under 40 CFR Part 1036.
        """
    },

    "test_3_ambiguous": {
        "doc_id": "TEST-003",
        "source": "OSHA Portal",
        "title": "Workplace Chemical Exposure Safety Standards 2024",
        "doc_type": "Interim Final Rule",
        "published_date": "2024-03-10",
        "source_url": "https://osha.gov/chemical-safety-2024",
        "raw_text": """
            OCCUPATIONAL SAFETY AND HEALTH ADMINISTRATION
            
            WORKPLACE CHEMICAL EXPOSURE SAFETY STANDARDS
            
            This regulation establishes permissible exposure limits for 
            various chemicals in manufacturing environments.
            
            Section 1: General manufacturing facilities must monitor 
                        airborne chemical concentrations.
            
            Section 2: Certain chemical compounds used in industrial 
                        processes may require additional ventilation.
            
            Section 3: Facilities producing mechanical components should 
                        review applicability based on their specific 
                        chemical usage.
            
            Note: Applicability depends on specific chemicals used 
                  in each facility's production process.
            
            Effective Date: December 1, 2024
        """
    },

    "test_4_new_regulation": {
        "doc_id": "TEST-004",
        "source": "EPA Federal Register",
        "title": "EPA Greenhouse Gas Reporting Rule - Power Generation Equipment 2024",
        "doc_type": "Final Rule",
        "published_date": "2024-02-20",
        "source_url": "https://epa.gov/ghg-power-gen-2024",
        "raw_text": """
            ENVIRONMENTAL PROTECTION AGENCY
            
            GREENHOUSE GAS REPORTING RULE
            Power Generation Equipment Emissions
            
            This regulation establishes mandatory greenhouse gas reporting 
            requirements for manufacturers of power generation equipment 
            including diesel generators, natural gas generators, and 
            industrial power systems.
            
            Section 1: All manufacturers of power generation equipment with 
                        annual production exceeding 500 units must report 
                        greenhouse gas emissions data annually.
            
            Section 2: Reporting must include CO2, CH4, and N2O emissions 
                        per unit of power output for each engine family.
            
            Section 3: Third-party verification required for manufacturers 
                        with more than 1000 units annual production.
            
            Section 4: Data submission deadline: March 31 each year
                        for the previous calendar year's production.
            
            Effective Date: January 1, 2025
            
            This is a new reporting requirement separate from existing 
            40 CFR Part 1037 greenhouse gas standards.
        """
    }
}