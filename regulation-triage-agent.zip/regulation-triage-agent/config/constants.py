# ============================================================
# CONSTANTS - Single source of truth
# CONFIDENCE_THRESHOLD shared across all agents & dashboard
# ============================================================

CONFIDENCE_THRESHOLD = 0.6          # Used for routing decision
URGENCY_DAYS_URGENT = 90            # Within 90 days = urgent
URGENCY_DAYS_ELEVATED = 180         # Within 180 days = elevated
PROMPT_VERSION = "v1"
MODEL_NAME = "azure/genailab-maas-gpt-4.1"