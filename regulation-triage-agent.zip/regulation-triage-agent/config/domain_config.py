# ============================================================
# DOMAIN CONFIG - All domain vocabulary lives here
# NO industry terms inside prompt text
# ============================================================

MANUFACTURING_CONFIG = {
    "organization_profile": (
        "A global manufacturer of heavy-duty diesel engines and power "
        "solutions, operating across multiple product lines, manufacturing "
        "plants, and international markets. Products include on-highway "
        "and off-highway engines, power generation equipment."
    ),
    "scope_dimensions": [
        "Product Lines: Heavy-duty diesel engines, natural gas engines, power generation",
        "Plants: North America, Europe, Asia Pacific",
        "Markets: On-highway, Off-highway, Industrial, Marine"
    ],
    "tracked_regulations": [
        {
            "id": "EPA-2023-HDE-001",
            "title": "EPA Heavy-Duty Engine NOx Standards 2023",
            "identifier": "40 CFR Part 1036"
        },
        {
            "id": "ECHA-2023-PFAS-001",
            "title": "PFAS Restriction Regulation",
            "identifier": "REACH Annex XVII"
        },
        {
            "id": "EPA-2022-GHG-001",
            "title": "Greenhouse Gas Emissions Standards",
            "identifier": "40 CFR Part 1037"
        },
        {
            "id": "ISO-2021-8178",
            "title": "Engine Emission Test Methods",
            "identifier": "ISO 8178"
        }
    ]
}