import httpx
from langchain_openai import ChatOpenAI
from config.constants import MODEL_NAME, PROMPT_VERSION

# Disable SSL for corporate network
http_client = httpx.Client(verify=False)

def get_llm():
    return ChatOpenAI(
        base_url="https://genailab.tcs.in",
        model=MODEL_NAME,
        api_key="sk-irQRPPSRcogLdyg-S0wJRg",
        http_client=http_client,
        temperature=0.1
    )

def get_model_info():
    return {
        "model_name": MODEL_NAME,
        "prompt_version": PROMPT_VERSION
    }