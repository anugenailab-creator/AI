import os
import sys
import logging
from datetime import datetime

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from langchain.schema import HumanMessage, SystemMessage
from config.llm_config import get_llm, get_model_info
from config.constants import CONFIDENCE_THRESHOLD, PROMPT_VERSION
from utils.json_parser import safe_parse_json
from utils.schema_validator import validate_triage_output
from utils.excel_reader import load_system_db

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

AGENT_NAME = "TriageAgent"

class TriageAgent:
    """
    Agent 1: Triage Agent
    Maps to FR-06 through FR-09
    Decides whether a retrieved document deserves attention,
    and what kind of attention it needs.
    """

    def __init__(self):
        self.llm = get_llm()
        self.model_info = get_model_info()
        self.prompt_template = self._load_prompt()
        self.system_db = load_system_db()
        print(f"\n✅ {AGENT_NAME} initialized")
        print(f"   Model         : {self.model_info['model_name']}")
        print(f"   Prompt Version: {PROMPT_VERSION}")
        print(f"   Threshold     : {CONFIDENCE_THRESHOLD}")

    def _load_prompt(self) -> str:
        """Load versioned prompt from file"""
        prompt_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "prompts", "triage_v1.txt"
        )
        with open(prompt_path, 'r') as f:
            content = f.read()
        print(f"✅ Prompt loaded: triage_v1.txt")
        return content

    def _build_prompt(self, document: dict) -> str:
        """
        Build final prompt by injecting config values
        No domain vocabulary hard-coded - all from system_db
        """
        today_date = datetime.today().strftime("%Y-%m-%d")

        prompt = self.prompt_template.format(
            # From system DB - no hard coding
            organization_profile=self.system_db["organization_profile"],
            scope_dimensions="\n".join(self.system_db["scope_dimensions"]),
            tracked_regulations=str(self.system_db["tracked_regulations"]),

            # From document input
            document_title=document.get("title", ""),
            document_source=document.get("source", ""),
            document_doc_type=document.get("doc_type", ""),
            document_published_date=document.get("published_date", ""),
            document_raw_text=document.get("raw_text", ""),

            # Today's date - auto calculated
            today_date=today_date
        )
        return prompt

    def run(self, document: dict) -> dict:
        """
        Main triage function
        Input  : document dict
        Output : frozen schema JSON
        """
        print(f"\n{'='*60}")
        print(f"🔍 TRIAGE AGENT RUNNING")
        print(f"   Document ID : {document.get('doc_id', 'N/A')}")
        print(f"   Title       : {document.get('title', 'N/A')}")
        print(f"   Today Date  : {datetime.today().strftime('%Y-%m-%d')}")
        print(f"{'='*60}")

        # Build prompt with injected config
        full_prompt = self._build_prompt(document)

        # Call LLM - retry once on failure
        max_retries = 2
        last_error = None

        for attempt in range(1, max_retries + 1):
            try:
                print(f"\n🤖 Calling LLM... (Attempt {attempt}/{max_retries})")

                messages = [HumanMessage(content=full_prompt)]
                response = self.llm.invoke(messages)
                raw_response = response.content

                # Parse JSON safely
                result = safe_parse_json(
                    raw_response,
                    AGENT_NAME,
                    PROMPT_VERSION
                )

                # Ensure doc_id matches input
                result["doc_id"] = document.get("doc_id", result.get("doc_id", ""))

                # Validate against frozen schema
                validate_triage_output(result)

                # Log success
                logger.info(
                    f"Agent: {AGENT_NAME} | "
                    f"Model: {self.model_info['model_name']} | "
                    f"Prompt: {PROMPT_VERSION} | "
                    f"DocID: {document.get('doc_id')} | "
                    f"Result: {result.get('routing_decision')}"
                )

                return result

            except Exception as e:
                last_error = e
                print(f"⚠️  Attempt {attempt} failed: {e}")
                if attempt == max_retries:
                    # Fail loudly - never silently return default
                    print(f"❌ All {max_retries} attempts failed for {AGENT_NAME}")
                    raise RuntimeError(
                        f"{AGENT_NAME} failed after {max_retries} attempts. "
                        f"Last error: {last_error}"
                    )

    def display_result(self, result: dict):
        """Display triage result in readable format"""

        print(f"\n{'='*60}")
        print(f"📊 TRIAGE RESULT")
        print(f"{'='*60}")
        print(f"  Document ID   : {result.get('doc_id')}")
        print(f"  In Scope      : {'✅ YES' if result.get('in_scope') else '❌ NO'}")
        print(f"  Reasoning     : {result.get('scope_reasoning')}")
        print(f"  Relation      : {result.get('relation_to_existing').upper()}")
        print(f"  Related Reg ID: {result.get('related_regulation_id') or 'None'}")
        print(f"  Confidence    : {result.get('confidence')} "
              f"{'✅' if result.get('confidence', 0) >= CONFIDENCE_THRESHOLD else '⚠️ Below Threshold'}")
        print(f"  Urgency       : {result.get('urgency_flag').upper()}")
        print(f"  Routing       : {result.get('routing_decision').upper()}")
        print(f"{'='*60}")